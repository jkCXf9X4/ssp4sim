---
id: OD-003
title: Logging Levels Configurable at Runtime
summary: Logging levels are configurable per-sink at runtime via the JSON configuration file; hot-path logging can additionally be compiled out.
date: 2026-11-11
status: accepted
layers: [operation]
state: 05-operation/monitoring.md
artifacts:
  - docs/logging_guidlines.md
  - docs/configuration.md
supersedes: []
superseded_by: []
related: []
---

# OD-003: Logging Levels Configurable at Runtime

## Context

Operators need different logging verbosity for development vs. production use. Log levels are set per-sink in the configuration file.

## Decision

Make logging levels configurable per-sink at runtime via the JSON configuration file. Hot-path logging can additionally be compiled out for maximum performance.

## Rationale

Runtime configurability avoids rebuilds for log level changes, per-sink levels enable different verbosity per output, and the compile-time disable (`SSP4SIM_LOG_HOT_PATH`) eliminates hot-path overhead.

## Alternatives Considered

- Compile-time-only log levels
- Environment-variable log control

## Consequences

- Positive: verbosity adjusted without rebuilding; level config in the same JSON file as simulation settings.
- Negative: hot-path tracing requires a separate build with `SSP4SIM_LOG_HOT_PATH=ON`.

## Verification

Monitoring docs document the log level tiers and per-sink configuration.

## Review Trigger

None.