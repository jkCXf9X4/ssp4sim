---
id: OD-005
title: OpenTelemetry as the Distributed Observability Tier
summary: OpenTelemetry is the distributed observability contract for correlating spans and trace context across simulation components.
date: 2026-11-11
status: accepted
layers: [operation]
state: 05-operation/monitoring.md
artifacts:
  - docs/logging_guidlines.md
supersedes: []
superseded_by: []
related: []
---

# OD-005: OpenTelemetry as the Distributed Observability Tier

## Context

Distributed simulations need cross-process visibility that local terminal, file, JSON, and cutelog sinks cannot provide on their own. A trace-oriented tier must carry context across process boundaries and remain separate from the local logging profile.

## Decision

Use OpenTelemetry as the distributed observability tier for multi-process or multi-service simulations — the contract for correlating spans and trace context across simulation components.

## Rationale

OpenTelemetry is designed for distributed tracing and cross-service correlation, complements local logs instead of replacing them, and a standard observability contract reduces coupling between simulation code and any specific backend.

## Alternatives Considered

- Extending local sinks with process IDs
- A vendor-specific tracing API

## Consequences

- Positive: standard, backend-agnostic cross-process correlation.
- Negative: trace context propagation becomes part of distributed simulation design; metadata must stay consistent across components; separate from current local JSON and cutelog sinks.

## Verification

Monitoring docs document the distributed observability tier.

## Review Trigger

Revisit when the OpenTelemetry tier is implemented.