---
id: AD-002
title: fmi4c for FMI Adapter Layer
summary: FMU .so files are loaded via the vendored fmi4c C adapter, which wraps FMI 2.0 function resolution and lifecycle.
date: 2026-11-11
status: accepted
layers: [architecture]
state: 02-architecture/component-view.md
artifacts:
  - 3rdParty/fmi4c
  - lib/include/utils/fmi/fmi4c_adapter.hpp
  - tests/lib/core/test_fmi4c_adapter.cpp
supersedes: []
superseded_by: []
related: []
---

# AD-002: fmi4c for FMI Adapter Layer

## Context

FMU shared libraries are loaded at runtime using POSIX dlopen. The fmi4c library provides a C adapter that wraps FMI 2.0 function pointer resolution, model description parsing, and lifecycle management.

## Decision

Use fmi4c as the FMI adapter layer. FMU .so files are loaded via fmi4c, which handles platform-specific dlopen mechanics and FMI function pointer binding.

## Rationale

fmi4c provides a tested abstraction over raw dlopen/dlsym for FMI 2.0, is vendored as a 3rdParty dependency with no external runtime dependency, and handles platform-specific loading quirks such as Linux shared-library mode bits.

## Alternatives Considered

- Raw dlopen/dlsym without an adapter
- A different FMI adapter library

## Consequences

- Positive: tested dlopen abstraction; vendored, no external runtime dependency.
- Negative: security patches require manual vendor updates; FMU vendor code runs in-process with full privileges (intentional lack of sandboxing).

## Verification

fmi4c adapter tests exist in `tests/lib/core/test_fmi4c_adapter.cpp`.

## Review Trigger

Revisit when the vendored fmi4c needs a major upstream bump.