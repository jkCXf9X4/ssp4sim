---
id: VD-001
title: C++ for Unit Tests, Python for Workflow Tests
summary: C++ Catch2 covers unit/integration tests; Python pytest covers workflow-level tests and result validation.
date: 2026-11-11
status: accepted
layers: [verification]
state: 04-verification/test-strategy.md
artifacts:
  - tests/README.md
  - docs/build_from_source.md
supersedes: []
superseded_by: []
related: []
---

# VD-001: C++ for Unit Tests, Python for Workflow Tests

## Context

The test suite uses both C++ (Catch2) and Python (pytest) for different testing levels: C++ for low-level library behavior, Python for end-to-end workflows.

## Decision

Use C++ Catch2 for unit and integration tests and Python pytest for workflow-level tests and result validation.

## Rationale

C++ tests run without Python interpreter overhead for tight-loop primitives, while pytest provides superior fixture management, parameterization, and xfail tracking, and reference sweeps are easier to maintain in Python with file discovery tools.

## Alternatives Considered

- All tests in C++
- All tests in Python

## Consequences

- Positive: each level uses the best-fit tooling.
- Negative: the build must produce both test artifacts (C++ binary + Python extension); some tests have dual coverage by design.

## Verification

The test pyramid in `04-verification/test-strategy.md` and `tests/README.md`.

## Review Trigger

None.