---
id: AD-006
title: Pre-Simulation Pipeline — Parsing, Analysis Projection, and Simulation Graph
summary: A staged pre-simulation pipeline hands a resolved connection graph to simulation-graph construction; algebraic-loop detection runs at execution time.
date: 2026-11-11
status: accepted
layers: [architecture]
state: 02-architecture/component-view.md
artifacts:
  - lib/include/pre
  - lib/include/simulation
  - tests/lib/analysis
supersedes: [AD-005]
superseded_by: []
related: []
---

# AD-006: Pre-Simulation Pipeline

## Context

AD-005 defined three layers with the simulation layer consuming the pure-data system through a query API. Implementation refined this into a staged pre-simulation pipeline: the handoff boundary moved to a resolved connection graph, and algebraic-loop detection moved to execution time over the runtime graph.

## Decision

Introduce a staged pre-simulation pipeline under a single orchestration point. Stage 1 parses the full SSP into a canonical data model; Stage 2 projects it into a transient structural view and derives the resolved connection topology; Stage 3 builds runtime models, wires connections, and derives execution edges from the resolved graph. Algebraic-loop detection runs at execution time over the runtime simulation graph.

## Rationale

A resolved-graph handoff removes string-based topology lookups from the simulation stage and makes the boundary testable; the canonical model stays the single source of truth; algorithm placement matches data availability (feedthrough/wiring only exist after graph construction).

## Alternatives Considered

- Keep the three-layer split of AD-005 with direct query-API handoff
- Run algebraic-loop detection during analysis

## Consequences

- Positive: each stage's output is independently testable; clean, explicit handoff boundary; single source of truth.
- Negative: supersedes the AD-005 three-layer handoff; legacy analysis/graph paths are removed.

## Verification

Pipeline stage tests under `tests/lib/analysis/` and simulation graph tests under `tests/lib/`.

## Review Trigger

Revisit if a stage boundary or the execution-time graph analysis needs to change.