---
id: VD-002
title: Known Xfails Tracked as Pytest Markers
summary: Known failures are tracked as strict pytest xfail markers with rationale; XPASS detection flags newly passing tests.
date: 2026-11-11
status: accepted
layers: [verification]
state: 04-verification/regressions.md
artifacts:
  - tests/README.md
  - docs/breakdown/04-verification/regressions.md
supersedes: []
superseded_by: []
related: []
---

# VD-002: Known Xfails Tracked as Pytest Markers

## Context

Two parameter-set variants (`signal_sine_gain_add/baseline`, `dcmotor/baseline`) were known to produce different start values than fixtures declared and were initially tracked as strict xfail markers. Both were later resolved: REG-001 by IMP-018 (namespace corrected ssv→ssd) and REG-002 by IMP-019 (component-level parameter binding traversal added to `get_parameter_bindings()`).

## Decision

Track known failures as strict pytest xfail markers with documented rationale, using XPASS detection to identify when a previously failing test starts passing.

## Rationale

Strict xfail markers produce XPASS when a test starts passing, alerting the team; markers are colocated with test code, reducing documentation drift.

## Alternatives Considered

- A separate regressions document only
- Skipping known-failing tests

## Consequences

- Positive: XPASS alerts on resolution; markers colocated with code.
- Negative: new xfails must include rationale strings; a regressions document complements markers with issue IDs and root-cause tracking.

## Verification

The regressions table in `04-verification/regressions.md` tracks the fixed issues.

## Review Trigger

Update when a new known failure appears or an XPASS fires.