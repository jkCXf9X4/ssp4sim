---
id: TD-002
title: Use pytest for Python Workflow Tests
summary: Python workflow tests use pytest, with reference SSP fixtures discovered through parameterization.
date: 2026-11-11
status: accepted
layers: [implementation]
state: 04-verification/test-strategy.md
artifacts:
  - tests/python
  - tests/python/conftest.py
supersedes: []
superseded_by: []
related: []
---

# TD-002: Use pytest for Python Workflow Tests

## Context

Python-level workflow tests use pytest for test execution and fixture management.

## Decision

Use pytest for Python tests. Tests discover reference SSP fixtures through pytest parameterization.

## Rationale

Pytest provides superior parameterization for reference sweeps, fixture discovery and comparison tooling are Python-side, and xfail markers track known issues at the test level.

## Alternatives Considered

- unittest
- A bespoke Python runner

## Consequences

- Positive: powerful parameterization and fixture management.
- Negative: Python 3.9+ required; tests import pyssp4sim from the build directory rather than an installed wheel.

## Verification

Two Python test files: a high-level reference sweep and a CLI smoke test.

## Review Trigger

None.