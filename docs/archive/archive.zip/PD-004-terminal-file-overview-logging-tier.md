---
id: PD-004
title: Terminal and File as the Overview Logging Tier
summary: Terminal output and a plain text file form the overview logging tier for local runs.
date: 2026-11-11
status: accepted
layers: [product]
state: 01-product/logging-output-artifact-strategy.md
artifacts:
  - docs/logging_guidlines.md
  - docs/configuration.md
supersedes: []
superseded_by: []
related: []
---

# PD-004: Terminal and File as the Overview Logging Tier

## Context

Operators need a low-friction view of simulation progress that works without additional tools. Terminal output gives immediate feedback during a run, and a plain text file preserves the same overview for later inspection.

## Decision

Use terminal and plain text file logging as the overview tier for local runs, optimized for quick human reading rather than exhaustive structured analysis.

## Rationale

Terminal output is visible immediately during startup, execution, and shutdown, and a plain text file preserves the same messages for later review, covering the most common operational workflow with minimal setup.

## Alternatives Considered

- Terminal only
- File only

## Consequences

- Positive: overview logs stay concise and high-signal; warnings and failures are easy to spot.
- Negative: deeper structured analysis belongs to the JSON tier, not the overview.

## Verification

Operator-facing logging guidance documents the overview tier.

## Review Trigger

None.