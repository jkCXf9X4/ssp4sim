---
id: PD-001
title: Local Database as Primary Result Artifact
summary: Local database output is the primary result-artifact category; CSV is a portable export, remote DB is deferred.
date: 2026-11-11
status: accepted
layers: [product]
state: 01-product/result-artifact-strategy.md
artifacts:
  - docs/usage.md
  - docs/configuration.md
supersedes: []
superseded_by: []
related: []
---

# PD-001: Local Database as Primary Result Artifact

## Context

Result artifacts must serve three access patterns: local database for indexed viewers and run-to-run comparison, pure CSV for universal access, and remote database for multi-source ingestion. The current implementation supports CSV and SQLite WAL local files; remote output is not implemented.

## Decision

Make the local database the primary result-artifact category. CSV remains a portable export path, not the core query layer. Remote database output stays a future category, represented as unavailable until a sink and configuration surface exist.

## Rationale

CSV is universally portable but poor for indexed time-window queries because viewers must scan growing files. A typed, queryable local store serves viewers and comparison tools, while remote databases fit multi-producer dashboards.

## Alternatives Considered

- CSV as the primary query layer
- Remote database first

## Consequences

- Positive: local database always available; multiple sinks on one event stream; CSV remains interoperable.
- Negative: remote database requires a separate product decision, dependency decision, and configuration contract.

## Verification

Recording pipeline produces both CSV and SQLite local artifacts; usage docs treat CSV as an export path.

## Review Trigger

Revisit when a remote database sink and configuration contract are proposed.