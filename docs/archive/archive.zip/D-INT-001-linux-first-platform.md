---
id: D-INT-001
title: Linux-First Platform Focus
summary: Linux (Ubuntu 22.04 x86_64) is the sole supported platform; portability is out of scope.
date: 2026-11-11
status: accepted
layers: [intent]
state: 00-intent/constraints.md
artifacts:
  - docs/development.md
  - docs/linux_binary_distribution.md
  - docs/build_from_source.md
supersedes: []
superseded_by: []
related: []
---

# D-INT-001: Linux-First Platform Focus

## Context

Development and release workflows target Linux, with Ubuntu 22.04 x86_64 as the primary build and runtime platform. Container builds, CI pipelines, and binary distribution are Linux-only. The SSP and FMI co-simulation ecosystem is predominantly Linux-based.

## Decision

Adopt Linux as the sole supported platform. No Windows or macOS support is planned at the intent level; platform portability is explicitly out of scope.

## Rationale

Narrowing the platform scope keeps the codebase compact and the CI matrix small, consistent with the project's experimental, small-surface-area posture. All existing build infrastructure is Linux-specific.

## Alternatives Considered

- Multi-platform support with per-OS CI
- Linux-primary with best-effort Windows/macOS

## Consequences

- Positive: compact build and CI matrix; releases are Linux-only.
- Negative: users on non-Linux platforms must use containers or VMs.

## Verification

Build and release pipelines run on the Linux CI runner only.

## Review Trigger

Revisit if a consumer requires a non-Linux platform.