---
id: TD-001
title: Use Catch2 for C++ Tests
summary: C++ unit and integration tests use the Catch2 framework with test_*.cpp naming.
date: 2026-11-11
status: accepted
layers: [implementation]
state: 04-verification/test-strategy.md
artifacts:
  - tests/lib
  - tests/lib/test_main.cpp
  - docs/build_from_source.md
supersedes: []
superseded_by: []
related: []
---

# TD-001: Use Catch2 for C++ Tests

## Context

C++ unit and integration tests use the Catch2 testing framework.

## Decision

Use Catch2 for C++ tests. Test files follow the `test_*.cpp` naming convention, with CTest as the canonical test runner.

## Rationale

Catch2 is header-only (v2) or minimal (v3) and easy to integrate, supports BDD-style sections, test case tagging, and custom reporters, and is well established in the C++ ecosystem.

## Alternatives Considered

- GoogleTest / doctest
- A custom test harness

## Consequences

- Positive: expressive, well-supported tests.
- Negative: Catch2 is a build dependency (handled via vcpkg).

## Verification

CTest runs the Catch2 binaries (see `docs/build_from_source.md`, `tests/README.md`).

## Review Trigger

None.