---
id: OD-002
title: File-Based Output Only For Current Releases
summary: Current releases write file-based output only; no streaming, socket, or network output; remote database ingestion is a future category.
date: 2026-11-11
status: accepted
layers: [operation]
state: 01-product/result-artifact-strategy.md
artifacts:
  - docs/usage.md
  - docs/configuration.md
supersedes: []
superseded_by: []
related: []
---

# OD-002: File-Based Output Only For Current Releases

## Context

Simulation output is written to the filesystem as CSV files or a SQLite database. The desired result-artifact model has three categories (CSV, local database, remote database), of which only the first two are available today.

## Decision

Limit output to files in version 1: no streaming, socket, or network output. Remote database ingestion is a future category, not an operator-visible feature in the current release line; when added, the canonical remote interface is InfluxDB Line Protocol (`OD-004`).

## Rationale

File-based output is the simplest and most portable approach with no network infrastructure dependencies, aligns with the project's narrow runtime surface, and defers the service availability, credentials, batching, retry, and schema-versioning concerns of remote databases.

## Alternatives Considered

- Streaming/socket output in version 1
- Remote database ingestion now

## Consequences

- Positive: simple, portable output; available immediately after simulation completion.
- Negative: no real-time or remote monitoring; storage management is the operator's responsibility; multi-source ingestion requires an external import path.

## Verification

Result artifact strategy marks remote database as deferred.

## Review Trigger

Revisit when a remote database contract is proposed.