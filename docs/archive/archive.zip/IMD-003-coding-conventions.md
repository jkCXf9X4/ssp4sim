---
id: IMD-003
title: Coding Conventions
summary: The codebase follows the coding conventions documented in docs/development.md, with no enforced formatter.
date: 2026-11-11
status: accepted
layers: [implementation]
state: 03-implementation/code-structure.md
artifacts:
  - docs/development.md
supersedes: []
superseded_by: []
related: []
---

# IMD-003: Coding Conventions

## Context

SSP4SIM follows specific coding conventions covering formatting, naming, and design philosophy to maintain consistency across the codebase.

## Decision

Adopt the coding conventions documented in `docs/development.md` (Coding Style section).

## Rationale

A consistent codebase reduces cognitive overhead, experimental software benefits from clear root-cause fixes over workarounds, and no enforced formatter keeps the build fast and avoids formatter version drift.

## Alternatives Considered

- clang-format with CI enforcement
- No documented conventions

## Consequences

- Positive: consistent style without formatter build coupling.
- Negative: contributors must match style manually; code review catches formatting issues instead of automated tools.

## Verification

Code review enforces the documented conventions.

## Review Trigger

Revisit if a formatter is introduced.