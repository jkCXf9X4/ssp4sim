---
id: IMD-002
title: Static Library with Minimal Public Headers
summary: All engine modules compile into a single static library with public headers separated in lib/public_include/.
date: 2026-11-11
status: accepted
layers: [implementation]
state: 03-implementation/code-structure.md
artifacts:
  - lib/CMakeLists.txt
  - lib/public_include
supersedes: []
superseded_by: []
related: []
---

# IMD-002: Static Library with Minimal Public Headers

## Context

All engine modules compile into a single static library (`libssp4sim.a`). Public API headers are separated from private headers.

## Decision

Build as a static library, separating public headers in `lib/public_include/` from private implementation headers in `lib/include/`.

## Rationale

Static linking avoids shared-library versioning for an experimental project, public-header separation enforces API discipline, and a single link target simplifies the build.

## Alternatives Considered

- Shared library with versioned ABI
- Single public header file

## Consequences

- Positive: clear API surface; simple build.
- Negative: consumers must relink when the library changes; public API additions require updating public_include/ and the CMake public include directory.

## Verification

The public include directory confines the API surface.

## Review Trigger

Revisit if a shared-library consumer is introduced.