---
id: VD-004
title: Reference SSP Fixtures Are Static and Version-Controlled
summary: Reference SSP fixtures under resources/reference_ssp/ are static, version-controlled artifacts following the fixture management policy.
date: 2026-11-11
status: accepted
layers: [verification]
state: 04-verification/test-strategy.md
artifacts:
  - resources/reference_ssp/AGENTS.md
  - tests/README.md
supersedes: []
superseded_by: []
related: []
---

# VD-004: Reference SSP Fixtures Are Static and Version-Controlled

## Context

The reference SSP fixtures under `resources/reference_ssp/` are unpacked, version-controlled SSP archives used by high-level workflow tests. They include a nested Git repository and generated build/ content.

## Decision

Keep reference SSP fixtures as static, version-controlled artifacts in the repository, following the fixture management policy in `resources/reference_ssp/AGENTS.md`.

## Rationale

Static fixtures ensure deterministic test execution across environments, version control provides traceability, and AGENTS.md documents the specific rules for editing the fixture tree.

## Alternatives Considered

- Generate fixtures at test time
- Store fixtures outside the repository

## Consequences

- Positive: deterministic, traceable fixture data for the reference SSP sweep.
- Negative: fixture size increases repository size; generated outputs must not be edited; updates require PR review; FMU binaries must preserve executable permissions.

## Verification

Workflow tests consume the static fixture tree per `resources/reference_ssp/AGENTS.md`.

## Review Trigger

None.