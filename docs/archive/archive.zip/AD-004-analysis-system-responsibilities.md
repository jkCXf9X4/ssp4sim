---
id: AD-004
title: AnalysisSystem — Responsibilities and Data Model Separation
summary: Introduced a standalone AnalysisSystem data model with vector storage and string-based references, decoupled from graph traversal.
date: 2026-11-11
status: superseded
layers: [architecture]
state: 02-architecture/component-view.md
artifacts:
  - lib/include/pre
  - lib/include/simulation
supersedes: [AD-003]
superseded_by: [AD-005]
related: []
---

# AD-004: AnalysisSystem — Responsibilities and Data Model Separation

## Context

The original `AnalysisGraph` served dual purpose as an SSP structural mirror and an intermediate execution-graph builder. Its data objects inherited from `utils::graph::Node`, coupling plain data to graph traversal, its builder only read top-level Components and Connections, and it used `std::map` indexing and raw back-pointers.

## Decision

Introduce a standalone `AnalysisSystem` data model: plain data classes without Node/IWritable inheritance, `std::vector`-based storage, string-based references instead of raw pointers, boundary connector support, and two builder entry points (path-based and pipeline-based). Graph algorithms (SCC, feedthrough) run as external operations over transient graph views.

## Rationale

Removing Node inheritance decouples data modeling from graph algorithms, vector storage simplifies iteration, string references eliminate pointer-wiring passes, and two builder entry points support both standalone analysis and pipeline integration.

## Alternatives Considered

- Keep and patch the legacy AnalysisGraph
- Introduce a shared-memory graph database

## Consequences

- Positive: nested SSP support; standalone analysis without the simulation pipeline; old tests kept passing via backward-compatible classes.
- Negative: superseded by AD-005 (three-layer architecture) and AD-006 (pre-simulation pipeline) which replaced the analysis/graph module tree.

## Verification

Superseded — current architecture recorded in AD-005/AD-006 and `02-architecture/component-view.md`.

## Review Trigger

None — superseded by AD-005.