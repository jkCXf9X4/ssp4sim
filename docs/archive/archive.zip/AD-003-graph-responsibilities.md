---
id: AD-003
title: Graph Responsibility Separation
summary: Separated the analysis graph (SSP mirror, no model-to-model edges) from the simulation graph (flattened runtime graph).
date: 2026-11-11
status: superseded
layers: [architecture]
state: 02-architecture/component-view.md
artifacts:
  - lib/include/pre
  - lib/include/simulation
supersedes: []
superseded_by: [AD-004]
related: []
---

# AD-003: Graph Responsibility Separation

## Context

The original codebase had a single `AnalysisGraph` that served both as a structural mirror of the SSP XML and as an intermediate step toward the execution graph. It could not parse nested systems (only top-level Components and Connections were read), and the boundary between analysis and simulation graph responsibilities was unclear. The `dcmotor` reference SSP (3 nesting levels) demonstrated the need for hierarchical support.

## Decision

Introduce a clear separation between two graph layers: the analysis graph parses all SSP information into local graph nodes (models, connectors, connections, internal variables) with no model-to-model edges, and the simulation graph flattens the hierarchy into the runtime model-to-model dependency graph.

## Rationale

Recursive traversal maps naturally to the SSP schema, keeping the analysis graph close to the SSP avoids premature flattening, and the simulation graph becomes the single source of truth for execution ordering. System connector models provide a natural resolution point for boundary connections.

## Alternatives Considered

- Keep a single merged analysis/simulation graph
- Build model-to-model edges in the analysis graph

## Consequences

- Positive: nested SSPs with arbitrary depth are supported; flat SSPs remain backward compatible.
- Negative: the approach was superseded by AD-004 (AnalysisSystem data model) and then AD-005/AD-006 (pipeline), which replaced the analysis graph implementation.

## Verification

Superseded — current architecture recorded in AD-004..AD-006 and `02-architecture/component-view.md`.

## Review Trigger

None — superseded by AD-004.