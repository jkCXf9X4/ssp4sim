---
id: OD-004
title: InfluxDB Line Protocol as Remote Result Interface
summary: InfluxDB Line Protocol is the canonical wire format for remote result ingestion, independent of the InfluxDB product.
date: 2026-11-11
status: accepted
layers: [operation]
state: 01-product/result-artifact-strategy.md
artifacts:
  - docs/usage.md
  - docs/configuration.md
supersedes: []
superseded_by: []
related: []
---

# OD-004: InfluxDB Line Protocol as Remote Result Interface

## Context

Remote result ingestion needs a stable interface that supports multiple backend databases and multiple simulation producers while staying independent of any specific remote database product.

## Decision

Use InfluxDB Line Protocol as the canonical remote result interface. Remote result sinks and adapters should accept or emit this line-oriented time-series format as their external contract — a wire-format decision, not a mandate to use the InfluxDB server product.

## Rationale

Line protocol is compact, text-based, and easy to batch, maps naturally onto timestamped simulation results with tags and fields, and keeps the engine decoupled from any single remote database while making future adapters shareable.

## Alternatives Considered

- A proprietary binary remote format
- A vendor-specific database client API

## Consequences

- Positive: engine decoupled from remote database products; shared canonical wire format.
- Negative: remote database implementations must define a lossless mapping to the line protocol contract; shared metadata (run id, source id, model, storage, variable, time) must be represented consistently.

## Verification

Result artifact strategy documents the remote interface as InfluxDB Line Protocol.

## Review Trigger

Revisit when a remote database sink is implemented.