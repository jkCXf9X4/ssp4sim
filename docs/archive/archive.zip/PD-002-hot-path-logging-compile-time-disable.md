---
id: PD-002
title: Hot-Path Logging Compile-Time Disable
summary: Hot-path logging is compiled out at build time via the SSP4SIM_LOG_HOT_PATH CMake option.
date: 2026-11-11
status: accepted
layers: [product]
state: 01-product/logging-output-artifact-strategy.md
artifacts:
  - docs/logging_guidlines.md
  - docs/development.md
supersedes: []
superseded_by: []
related: []
---

# PD-002: Hot-Path Logging Compile-Time Disable

## Context

Logging inside simulation hot paths (step, substep, executor loops) can significantly impact performance. Developers need to compile out hot-path logging for production runs while retaining it for debugging.

## Decision

Control hot-path logging at compile time via the `SSP4SIM_LOG_HOT_PATH` CMake option. When OFF, hot-path log statements are compiled out entirely.

## Rationale

Compile-time removal eliminates any runtime overhead from disabled statements, lets developers toggle debug and optimized builds without source changes, and matches the project's performance-aware posture.

## Alternatives Considered

- Runtime log-level filtering in hot paths
- Always-on hot-path logging

## Consequences

- Positive: zero overhead when disabled; toggling without source edits.
- Negative: two build configurations needed; guard macros (`IF_LOG`) required in performance-sensitive code.

## Verification

Profiling builds with the option OFF show no hot-path log overhead.

## Review Trigger

Revisit if runtime filtering ever becomes cheap enough to replace compile-time removal.