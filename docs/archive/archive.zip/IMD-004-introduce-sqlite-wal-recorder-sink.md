---
id: IMD-004
title: Introduce SQLite WAL Recorder Sink
summary: A SqliteWALRecorderSink writes simulation data to a SQLite database file with WAL journal mode.
date: 2026-11-11
status: accepted
layers: [implementation]
state: 03-implementation/modules/signal.md
artifacts:
  - vcpkg.json
  - lib/CMakeLists.txt
  - lib/public_include/shared_config.hpp
  - lib/include/simulation/signal/sinks/sqlite_recorder_sink.hpp
  - lib/include/simulation/signal/sinks/sqlite_recorder_sink.cpp
  - lib/include/simulation/signal/sinks/sqlite_recorder_utils.hpp
  - lib/include/simulation/signal/sinks/sqlite_recorder_storage.hpp
  - lib/include/simulation.cpp
  - tests/lib/core/test_sqlite_recorder.cpp
  - docs/configuration.md
supersedes: [PD-003]
superseded_by: []
related: []
---

# IMD-004: Introduce SQLite WAL Recorder Sink

## Context

The local database recording layer needed a local database backend. A SQLite sink with WAL journal mode offers concurrent reads during ongoing writes, a simple prepared-statement interface, ubiquitous tooling, and no server process.

## Decision

Add `SqliteWALRecorderSink`, a recorder sink that writes simulation data into a SQLite database file with WAL journal mode enabled. WAL allows one writer and multiple simultaneous readers.

## Rationale

SQLite WAL enables a live viewer to query the file while the simulation runs; explicit transactions committing every 100 rows balance durability with batch efficiency; FMI 2.0 types map to simple SQLite storage classes.

## Alternatives Considered

- DuckDB (superseded by this choice per PD-003)
- Remote database sink

## Consequences

- Positive: concurrent local reads; event-per-row recording; replaces DuckDB as the local backend.
- Negative: new build dependency (unofficial-sqlite3 via vcpkg); new config keys `simulation.recording.sqlite.*`.

## Verification

Dedicated C++ tests in `tests/lib/core/test_sqlite_recorder.cpp`; coverage in `03-implementation/modules/signal.md`.

## Review Trigger

Revisit when concurrent-writer behavior or checkpoint control for very long runs is needed.