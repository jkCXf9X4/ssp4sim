---
id: AD-005
title: Three-Layer Architecture — Analysis System, Analysis Graph, and Simulation Graph
summary: Formalized three layers: AnalysisSystem (pure data), transient AnalysisGraphFactory (graph views), and the simulation graph.
date: 2026-11-11
status: superseded
layers: [architecture]
state: 02-architecture/component-view.md
artifacts:
  - lib/include/pre
  - lib/include/simulation
supersedes: [AD-004]
superseded_by: [AD-006]
related: []
---

# AD-005: Three-Layer Architecture

## Context

The analysis layer evolved through two generations: a flat `AnalysisGraph` (pre-IMP-039) coupling data to graph algorithms, then a hierarchical `AnalysisSystem` (IMP-039/IMP-040) with plain data classes. AD-005 formalized the second generation as three distinct layers with an eager-loading contract.

## Decision

Define three layers: Layer 1 `AnalysisSystem` loads the full SSP into runtime-free plain data and hands `const AnalysisSystem&` to Layer 2; Layer 2 `AnalysisGraphFactory` builds transient graph views for SCC/algebraic-loop detection; Layer 3 `GraphBuilder` consumes the analysis system's query API to build the simulation graph. Feedthrough stays in Layer 3.

## Rationale

Separation of concerns keeps data, graph algorithms, and simulation construction in distinct layers; the pure-data handoff is independently testable; transient graph lifetimes avoid leaking graph state into the data model.

## Alternatives Considered

- Reuse the legacy AnalysisGraph
- Store persistent graph state on the AnalysisSystem

## Consequences

- Positive: independently testable layers; transient graph views; SCC delegated via a single discoverable entry point.
- Negative: superseded by AD-006 (pre-simulation pipeline) which moved the handoff to a resolved connection graph and graph analysis to execution time.

## Verification

Superseded — current architecture recorded in AD-006 and `02-architecture/component-view.md`.

## Review Trigger

None — superseded by AD-006.