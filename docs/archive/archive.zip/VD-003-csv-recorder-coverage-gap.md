---
id: VD-003
title: CSV Recorder Coverage Gap
summary: The CSV recorder has no dedicated unit test; coverage through the smoke and workflow tests is accepted for the experimental phase.
date: 2026-11-11
status: accepted
layers: [verification]
state: 04-verification/coverage-targets.md
artifacts:
  - tests/README.md
  - docs/breakdown/04-verification/coverage-targets.md
supersedes: []
superseded_by: []
related: []
---

# VD-003: CSV Recorder Coverage Gap

## Context

DuckDB recorder had dedicated C++ unit tests; the CSV recorder had none, being tested only through the C++ high-level smoke test and Python workflow tests. The DuckDB recorder tests were later removed per IMP-034, but the CSV test gap decision remains current.

## Decision

Accept the CSV recorder unit test gap. Coverage through the smoke test and workflow tests is sufficient for the experimental phase.

## Rationale

CSV recording is exercised in every workflow test that produces output, a dedicated test would duplicate that coverage, and the CSV recorder is simpler (row-oriented, no schema) and less likely to have format-specific bugs than a database-backed recorder.

## Alternatives Considered

- Add a dedicated CSV unit test
- Remove all CSV coverage

## Consequences

- Positive: avoids duplicating workflow coverage.
- Negative: CSV format compliance is not validated in isolation; if CSV-specific bugs appear, a dedicated unit test should be added.

## Verification

The coverage gap is documented in `04-verification/coverage-targets.md`.

## Review Trigger

Add a dedicated CSV unit test when CSV-specific bugs appear.