---
id: AD-001
title: Modular Monolith with Static Library Boundary
summary: Engine modules build into a single static library with an explicit public header API boundary.
date: 2026-11-11
status: accepted
layers: [architecture]
state: 02-architecture/component-view.md
artifacts:
  - lib/CMakeLists.txt
  - lib/public_include
supersedes: []
superseded_by: []
related: []
---

# AD-001: Modular Monolith with Static Library Boundary

## Context

All engine modules build into a single static library (`libssp4sim.a`), exposing a minimal public API through `lib/public_include/` (simulator.hpp, simulator_c_api.h, shared_config.hpp). Internal modules communicate through direct C++ calls.

## Decision

Use a modular monolith architecture with a single static library boundary. Public headers are explicitly separated from private headers; internal modules are not independently deployable.

## Rationale

The engine is small enough that microservice or plugin architectures add needless complexity, static linking yields one binary per consumer (CLI, Python extension, test binary), and public-header separation provides a controlled API surface. Only FMU vendor code is loaded at runtime.

## Alternatives Considered

- Plugin / microservice architecture
- Shared library with dynamic loading of modules

## Consequences

- Positive: one binary per consumer; clear public API; no IPC or sandboxing overhead.
- Negative: any module change triggers a full rebuild of libssp4sim; no sandboxing between modules.

## Verification

Public API surface is confined to `lib/public_include/`.

## Review Trigger

Revisit if the engine grows large enough to justify dynamic module boundaries.