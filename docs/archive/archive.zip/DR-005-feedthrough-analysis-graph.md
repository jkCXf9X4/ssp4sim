---
id: DR-005
title: Feedthrough Detection via Analysis Graph Traversal
summary: Feedthrough is detected by BFS over the FMU internal dependency graph in the analysis layer, not via FMI API calls in the sim graph.
date: 2026-11-11
status: accepted
layers: [implementation]
state: 02-architecture/component-view.md
artifacts:
  - lib/include/pre
  - lib/include/simulation
supersedes: []
superseded_by: []
related: []
---

# DR-005: Feedthrough Detection via Analysis Graph Traversal

## Context

IMP-023 required per-variable feedthrough metadata on simulation graph connections. The initial approach used the FMI `get_dependencies_variables()` API in `GraphBuilder::wire_connections()`, which overcounted feedthrough (any output depending on internal state, e.g. a discrete integrator, was marked feedthrough) and duplicated work already done by the analysis graph's `wire_internal_dependencies()`.

## Decision

Move feedthrough detection to the analysis graph layer. Use BFS traversal of the existing FMU internal dependency graph from each output connector through its children; if an input connector of the same FMU is reachable, mark the output as feedthrough.

## Rationale

This yields correct semantics (only outputs with a transitive dependency on an input are feedthrough), reuses the analysis graph's dependency edges, and keeps structural computation in the analysis layer.

## Alternatives Considered

- FMI `get_dependencies_variables()` in the sim graph (rejected: overcounts, duplicates work)
- Heuristic connection inspection

## Consequences

- Positive: correct feedthrough semantics; no redundant FMI XML parsing; clean separation.
- Negative: BFS adds O(outputs × internal_edges) at build time, negligible for realistic FMUs; later refactors (AD-005/AD-006) moved feedthrough to wiring time.

## Verification

Analysis graph tests cover feedthrough propagation.

## Review Trigger

Revisit if the analysis-graph feedthrough approach is superseded by the pipeline architecture (AD-006).