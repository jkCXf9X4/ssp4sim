---
id: OD-001
title: Local Database as Default Recording Format
summary: The local database is the default recording format; CSV is an optional portable export path.
date: 2026-11-11
status: accepted
layers: [operation]
state: 01-product/result-artifact-strategy.md
artifacts:
  - docs/usage.md
  - docs/configuration.md
supersedes: []
superseded_by: []
related: []
---

# OD-001: Local Database as Default Recording Format

## Context

Simulation results can be recorded to a local database (default) or CSV export. Operators need to choose between queryability and portability.

## Decision

Make the local database the default recording format, with CSV optional as a portable export path.

## Rationale

The local database is the primary query layer for time-window and run-comparison workflows, while CSV is universally portable and requires no additional tooling.

## Alternatives Considered

- CSV as the default
- No default, explicit per-run choice always

## Consequences

- Positive: primary query workflows are served by default.
- Negative: operators needing a portable export must enable CSV; both can run concurrently.

## Verification

Result artifact strategy documents the local database as primary.

## Review Trigger

Revisit if a different default better serves operator workflows.