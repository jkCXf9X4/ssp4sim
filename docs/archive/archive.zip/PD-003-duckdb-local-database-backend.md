---
id: PD-003
title: DuckDB as Local Database Backend
summary: DuckDB was an optional local database recording backend, since removed in favor of SQLite WAL.
date: 2026-11-11
status: superseded
layers: [product]
state: 01-product/result-artifact-strategy.md
artifacts:
  - docs/usage.md
  - docs/configuration.md
supersedes: []
superseded_by: [IMD-004]
related: []
---

# PD-003: DuckDB as Local Database Backend

## Context

DuckDB recording was the initial local database result backend, requiring DuckDB library linkage and adding a dependency. It was treated as a post-run analytical store rather than a long-term answer for separate live writer and viewer processes.

## Decision

Make DuckDB an optional local database recording backend, not a replacement for CSV export; both can operate concurrently on the same event stream.

## Rationale

DuckDB offered better query capability for large datasets and better support for dynamic timesteps where models do not synchronize at each macro step. For live local viewing, SQLite WAL was judged a better future backend (one local writer, concurrent readers, single file).

## Alternatives Considered

- DuckDB as the sole local backend
- SQLite WAL from the start

## Consequences

- Positive: CSV remained available to users without DuckDB support.
- Negative: DuckDB required an additional build dependency; the recorder was later removed per IMP-034 and replaced by SQLite WAL (IMD-004).

## Verification

None — DuckDB recording removed; SQLite WAL is the current backend (IMD-004).

## Review Trigger

None — superseded by IMD-004.