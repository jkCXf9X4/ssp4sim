---
id: PD-005
title: Full JSON File as the Deep-Analysis Logging Tier
summary: A full JSON file is the canonical local structured log artifact for offline analysis and automation.
date: 2026-11-11
status: accepted
layers: [product]
state: 01-product/logging-output-artifact-strategy.md
artifacts:
  - docs/logging_guidlines.md
  - docs/configuration.md
supersedes: []
superseded_by: []
related: []
---

# PD-005: Full JSON File as the Deep-Analysis Logging Tier

## Context

Some investigations need the complete structured event stream, not just an operator overview. A JSON file provides a machine-readable archive that can be filtered, searched, or post-processed.

## Decision

Use a full JSON file as the deep-analysis logging tier and the canonical local log artifact for offline inspection and automation.

## Rationale

Structured logs are easier to filter and correlate than free-form text, JSON is broadly supported by command-line tools and scripts, and keeping the structured archive separate from the overview tier reduces noise for interactive runs.

## Alternatives Considered

- Structured binary log format
- Plain text with delimiters

## Consequences

- Positive: machine-readable, filterable archive via jq or scripts.
- Negative: the JSON file may be larger than the plain-text overview; enabled only when structured analysis is needed.

## Verification

Logging docs describe the JSON tier and its tooling.

## Review Trigger

None.