---
id: PD-006
title: Cutelog as the Live Structured Log Navigation Tier
summary: Cutelog is the live structured log navigation tier over the same JSON event stream used for deep analysis.
date: 2026-11-11
status: accepted
layers: [product]
state: 01-product/logging-output-artifact-strategy.md
artifacts:
  - docs/logging_guidlines.md
  - docs/configuration.md
supersedes: []
superseded_by: []
related: []
---

# PD-006: Cutelog as the Live Structured Log Navigation Tier

## Context

Operators sometimes need the full structured log stream while a simulation is still running. A live viewer is more useful than waiting for the run to finish when navigating a large or noisy log stream.

## Decision

Use cutelog as the live structured log navigation tier, an interactive view over the same structured JSON event stream used by the deep-analysis tier.

## Rationale

Cutelog makes it easier to jump through a live event stream than raw terminal output, the sink preserves structure while allowing real-time inspection, and it complements rather than replaces the terminal and JSON tiers.

## Alternatives Considered

- Live terminal tailing of the JSON file
- No live structured viewer

## Consequences

- Positive: real-time navigation of the structured stream.
- Negative: depends on a live listener; a navigation aid, not a durable archive; the rest of the profile must still work when the listener is unavailable.

## Verification

Logging docs describe the cutelog sink and its optional status.

## Review Trigger

None.