---
id: IMD-001
title: Use C++23 Standard
summary: SSP4SIM is written in C++23, requiring GCC 13+ or Clang 16+.
date: 2026-11-11
status: accepted
layers: [implementation]
state: 03-implementation/build-environment.md
artifacts:
  - CMakeLists.txt
  - docs/development.md
supersedes: []
superseded_by: []
related: []
---

# IMD-001: Use C++23 Standard

## Context

SSP4SIM is written in C++23, enabling designated initializers, std::expected for error handling, std::optional, std::span, and std::string_view.

## Decision

Use C++23 as the implementation language standard, requiring GCC 13+ or Clang 16+.

## Rationale

C++23 features reduce boilerplate and improve safety (std::expected over exceptions for expected errors), designated initializers improve configuration readability, and std::span provides safe bounded views.

## Alternatives Considered

- C++17 / C++20
- C with a C++ shim

## Consequences

- Positive: modern, safer standard library usage.
- Negative: requires recent toolchains (GCC 13+, Clang 16+); some std::expected support may still be stabilizing.

## Verification

Build environment documents GCC 13+/Clang 16+ requirements.

## Review Trigger

Revisit when default toolchains on supported distributions lag C++23.